#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>

int main(int argc,char *argv[])
{

    FILE *arq;
    FILE *copia;
    char str[800];
    char comando[800];
    char diretorio_atual[800];

     char ch='a';
    char c1;
    char palavra[]="<sheetProt";
    int i,imprime=1;
    fpos_t position;
    fpos_t anterior;
    fpos_t meio;


    DIR *dir;
    struct dirent *lsdir;


    dir = opendir(argv[1]);
    if(dir==NULL){

        printf("\n\n\nO =======================================================================================");
        printf("\n\n\nO DESBLOQUEIA SHEET EXCEL RECEBE CAMINHO  DA PASTA ATUA POR LINHA DE COMANDO");
        printf("\n\n\nO USE o arquivo .bat que faz todo o processo");
        printf("\n\n\nO =======================================================================================");
        printf("\n\n\nO =======================================================================================");
        printf("\n\n\nO =======================================================================================");


    }


    /* print all the files and directories within directory */
    while ( ( lsdir = readdir(dir) ) != NULL )
    {
        printf ("%s\n\n\n", lsdir->d_name);

       //junta o diretorio atual em que os arquivos serao modificados(%cd%/xl/worksheets) com o nome de acada arquivo
      sprintf(str,"%s\\%s",argv[1],lsdir->d_name);
      printf("O   %s ? \n",str);
      //Abre para leitura o xml na pasta %cd%/xl/worksheets
      arq = fopen(str, "r");

      //Cria uma copia do arquivo na mesma pasta do arquivo bat
      sprintf(diretorio_atual,"%s\\%s",argv[2],lsdir->d_name);
      copia=fopen(diretorio_atual, "w");
	 if(arq == NULL)
	    printf("Erro, nao foi possivel abrir o arquivo\n");
	 else
	    printf("O arquivo %s foi aberto\n",lsdir->d_name);


   while( ch!= EOF ){



		fgetpos (arq, &position);
		ch=fgetc(arq);
		fgetpos (arq, &anterior);


		fsetpos (arq, &position);




		for(i=0;i<=9;i++){if(((c1=fgetc(arq)))==palavra[i]){}
		else{break;}


		}


        if(i==10){imprime=0;}


        fsetpos (arq, &anterior);


		if(imprime==1){fprintf(copia,"%c",ch);/*putchar(ch)*/;}
		if((imprime==0)&&(ch=='>') ){imprime=1;}






   }

  ch='a';




    fclose(arq);
    fclose(copia);
    //Mover o arquivo
    sprintf(comando,"MOVE %s\\%s  %s\\",argv[2],lsdir->d_name,argv[1]);
    system(comando);

      }

    closedir(dir);


    return (0);
   system("pause");
}
